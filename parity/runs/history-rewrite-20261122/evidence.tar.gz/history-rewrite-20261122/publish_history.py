"""Publish the verified plan only with existing ysh0566 HTTPS credentials."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import urllib.request

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--execute", action="store_true")
parser.add_argument("--allow-public", action="store_true", help="Requires explicit human authorization to keep this repository public")
args = parser.parse_args()
root = Path(__file__).resolve().parents[2]
plan = json.loads((Path(__file__).parent / "push-plan.json").read_text())
if not args.execute:
    print(json.dumps({"writes": False, "requires_existing_git_login": "ysh0566", "plan": plan}, indent=2))
    raise SystemExit(0)
env = dict(os.environ, GIT_TERMINAL_PROMPT="0")

def git(*arguments):
    return subprocess.check_output(["git", "-C", str(root), *arguments], env=env, text=True).strip()

assert git("remote", "get-url", "origin") == "https://github.com/ysh0566/ponder-go.git"
credential = subprocess.run(["git", "-C", str(root), "credential", "fill"],
                            input="url=https://github.com/ysh0566/ponder-go.git\n\n",
                            env=env, text=True, capture_output=True)
values = dict(line.split("=", 1) for line in credential.stdout.splitlines() if "=" in line)
if credential.returncode or not values.get("password"):
    raise SystemExit("No existing HTTPS Git credential is configured. Configure the existing ysh0566 credential; do not create a token or use the other SSH account. Nothing was pushed.")

def api(path):
    request = urllib.request.Request("https://api.github.com" + path, headers={
        "Authorization": "Bearer " + values["password"], "Accept": "application/vnd.github+json", "User-Agent": "ponder-go-history-rewrite"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.load(response)

actor = api("/user")
if actor.get("login") != "ysh0566" or actor.get("id") != 19503475:
    raise SystemExit("Existing Git credential does not belong to ysh0566; nothing was pushed.")
repo = api("/repos/ysh0566/ponder-go")
assert repo["owner"]["login"] == "ysh0566" and repo["id"] == 1431001484
if not repo["private"] and not args.allow_public:
    raise SystemExit("AGENTS.md permits private publication only. Explicit human authorization is required before --allow-public; nothing was pushed.")
advertised = {}
for row in git("ls-remote", "--refs", "origin").splitlines():
    oid, ref = row.split()
    if ref.startswith(("refs/heads/", "refs/tags/")):
        advertised[ref] = oid
expected = {item["ref"]: item["expected_old"] for item in plan["refs"]}
assert advertised == expected, "Remote refs changed; re-audit instead of overwriting concurrent work"
for item in plan["refs"]:
    assert git("rev-parse", item["ref"]) == item["new"], "Local plan is stale"
command = ["push", "--atomic", "origin"]
command += ["--force-with-lease=" + item["ref"] + ":" + item["expected_old"] for item in plan["refs"]]
command += [item["new"] + ":" + item["ref"] for item in plan["refs"]]
git(*command)
observed = {ref: oid for oid, ref in (row.split() for row in git("ls-remote", "--refs", "origin").splitlines()) if ref.startswith(("refs/heads/", "refs/tags/"))}
assert observed == {item["ref"]: item["new"] for item in plan["refs"]}
git("config", "--replace-all", "remote.origin.fetch", "+refs/heads/*:refs/remotes/origin/*")
subprocess.run(["git", "-C", str(root), "config", "--unset-all", "remote.origin.skipDefaultUpdate"], check=False)
git("fetch", "--prune", "origin")
git("branch", "--set-upstream-to=origin/main", "main")
print(json.dumps({"published": True, "verified_login": actor["login"], "atomic_leased_refs": len(plan["refs"])}, indent=2))
