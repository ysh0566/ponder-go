"""Install only after independent clone/recovery acceptance, retaining original .git."""
import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path.cwd()
base = root / ".local/history-rewrite-20261122"
mirror = base / "filtered-v2.git"
install = base / "install.git"
backup = base / "original.git"
report = json.loads((root / "parity/runs/history-rewrite-20261122/slim-clone.json").read_text())
assert report["passed"] and report["main_git_did_not_grow"]
assert report["original_files_sha256_and_modes_verified"] == 35389
assert not backup.exists() and not install.exists()

def git(*args, directory=root):
    return subprocess.check_output(["git", "-C", str(directory), *args], text=True).strip()

old_head = git("rev-parse", "HEAD")
assert old_head == "936b5c6539c814c6a8079b2d53f1141efb857a3a"
assert git("branch", "--show-current") == "main"
assert not git("status", "--porcelain", "--untracked-files=no")
assert git("worktree", "list", "--porcelain").count("worktree ") == 1
new_head = git("rev-parse", "refs/heads/main", directory=mirror)
assert git("rev-parse", "HEAD^{tree}") == git("rev-parse", "refs/heads/main^{tree}", directory=mirror)
shutil.copytree(mirror, install, symlinks=True)
assert not (install / "objects/info/alternates").exists()
git("config", "core.bare", "false", directory=install)
git("config", "core.logallrefupdates", "true", directory=install)
subprocess.run(["git", "--git-dir=" + str(install), "--work-tree=" + str(root), "reset", "--mixed", "--quiet", new_head], check=True)
for name in ("info/exclude",):
    if (root / ".git" / name).is_file():
        shutil.copy2(root / ".git" / name, install / name)
# Both renames stay on the same filesystem. The original metadata is retained
# in full, including all old refs/reflogs, and rollback is immediate on failure.
os.rename(root / ".git", backup)
try:
    os.rename(install, root / ".git")
except BaseException:
    os.rename(backup, root / ".git")
    raise
assert git("rev-parse", "HEAD") == new_head
assert not git("status", "--porcelain", "--untracked-files=no")
assert subprocess.run(["git", "cat-file", "-e", "fe9f4729693c8040340656c6ce49dd2a788ad999"], capture_output=True).returncode != 0
git("fsck", "--full", "--no-reflogs")
# The failed first candidate remains inspectable against the saved old store.
alternate = base / "filtered.git/objects/info/alternates"
if alternate.exists():
    alternate.write_text(str(backup / "objects") + "\n")
result = {"old_head": old_head, "new_head": new_head, "original_git": str(backup),
          "all_working_files_unchanged": True, "original_git_preserved": True,
          "git_bytes": int(subprocess.check_output(["du", "-sb", str(root / ".git")], text=True).split()[0]),
          "old_objects_absent": True,
          "origin_fetch_suspended": "Nonexistent sentinel ref prevents accidentally reimporting the still-old public remote. Restore normal fetch only after leased remote publication."}
(root / "parity/runs/history-rewrite-20261122/install.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
