"""Prove a complete slim clone can restore all evidence from an external bundle."""
import gzip
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

root = Path.cwd()
run = root / "parity/runs/history-rewrite-20261122"
mirror = root / ".local/history-rewrite-20261122/filtered-v2.git"
backup = root / ".local/history-rewrite-20261122/original.bundle"
fresh = Path(tempfile.mkdtemp(prefix="ponder-go-slim-clone-"))
report = {"passed": False, "clone": str(fresh)}
started = time.time()

def git(*args, check=True):
    return subprocess.run(["git", "-C", str(fresh), *args], capture_output=True, check=check)

def object_bytes():
    return sum(p.stat().st_size for p in (fresh / ".git/objects").rglob("*") if p.is_file())

try:
    subprocess.run(["git", "clone", "--no-local", str(mirror), str(fresh)], check=True, capture_output=True)
    with gzip.open(fresh / "parity/archive-files.json.gz", "rt") as stream:
        catalog = json.load(stream)
    largest = max(catalog["files"], key=lambda x: x["bytes"])
    assert git("cat-file", "-e", catalog["source_commit"], check=False).returncode != 0
    assert git("cat-file", "-e", largest["git_blob"], check=False).returncode != 0
    assert not (fresh / ".git/objects/info/alternates").exists()
    before = object_bytes()
    report["clone_git_bytes"] = int(subprocess.check_output(["du", "-sb", str(fresh / ".git")], text=True).split()[0])
    report["clone_object_bytes"] = before
    report["shared_objects"] = False
    report["old_source_commit_absent"] = True
    report["old_largest_blob_absent"] = largest
    report["cloned_branches"] = git("branch", "-a").stdout.decode().splitlines()
    spec = importlib.util.spec_from_file_location("slim_archive", fresh / "tools/parity_archive.py")
    archive = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(archive)
    try:
        archive.verify(fresh)
        raise AssertionError("Missing external bundle must not silently succeed")
    except ValueError as error:
        assert "outside this repository" in str(error), str(error)
        report["missing_bundle_explicit_error"] = str(error)
    required = sum(x["bytes"] for x in catalog["files"]) + backup.stat().st_size + 512 * 1024 * 1024
    assert shutil.disk_usage(fresh).free > required, "Insufficient space for full restoration"
    report["restoration"] = archive.restore(fresh, bundle=backup)
    manifest, entries = archive.load_archive(fresh)
    all_entries = entries + manifest["retained_files"]
    for number, entry in enumerate(all_entries, 1):
        archive.unchanged(archive.safe_path(fresh, entry["path"]), entry)
        archive.progress("audit restored bytes and modes", number, len(all_entries))
    assert object_bytes() == before, "Archive objects must not be imported into main .git"
    assert git("cat-file", "-e", catalog["source_commit"], check=False).returncode != 0
    assert git("cat-file", "-e", largest["git_blob"], check=False).returncode != 0
    git("fsck", "--full", "--no-reflogs")
    report.update({"passed": True, "original_files_sha256_and_modes_verified": len(all_entries),
                   "original_bytes_verified": sum(x["bytes"] for x in all_entries),
                   "main_git_object_bytes_after_restoration": object_bytes(),
                   "main_git_did_not_grow": True, "cache": str(archive.archive_repository(fresh)),
                   "external_cache_bytes": int(subprocess.check_output(["du", "-sb", str(archive.archive_repository(fresh))], text=True).split()[0])})
    shutil.rmtree(fresh)
    report["temporary_clone_removed"] = True
except BaseException as error:
    report["error"] = repr(error)
    raise
finally:
    report["elapsed_seconds"] = round(time.time() - started, 3)
    (run / "slim-clone.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
