"""Freeze local rewrite acceptance and the separately blocked publication state."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
from datetime import datetime, timezone

root = Path.cwd()
run = root / "parity/runs/history-rewrite-20261122"
base = root / ".local/history-rewrite-20261122"
load = lambda name: json.loads((run / name).read_text())
audit = json.loads((base / "audit.json").read_text())
clone = load("slim-clone.json")
install = load("install.json")
assert clone["passed"] and clone["main_git_did_not_grow"]
assert load("independent-metadata-audit.json")["authors_committers_timestamps_messages_and_parent_graph_identical"]
assert (run / "archive-tests-01.log").read_text().rstrip().endswith("OK")
assert (run / "history-tests-02.log").read_text().rstrip().endswith("OK")
tests = []
for filename, command in (("go-test.log", "go test ./..."), ("go-race.log", "go test -race ./...")):
    outcomes = {}
    for line in (run / filename).read_text().splitlines():
        fields = line.split()
        if len(fields) > 1 and fields[0] in ("ok", "FAIL", "?") and fields[1].startswith("ponder.local/"):
            outcomes[fields[1]] = fields[0]
    assert len(outcomes) == 24 and "FAIL" in outcomes.values()
    tests.append({"command": "PATH=/tmp/ponder-go-parity-tools/go/bin:$PATH GOMODCACHE=/root/go/pkg/mod GOCACHE=/tmp/ponder-go-parity-gocache " + command,
                  "exit_code": 1, "status": "failed", "log": filename, "packages": outcomes,
                  "passed_packages": sum(v == "ok" for v in outcomes.values()),
                  "failed_packages": sum(v == "FAIL" for v in outcomes.values()),
                  "no_test_files": sum(v == "?" for v in outcomes.values())})
sources = [(p.name, p) for p in sorted(run.iterdir()) if p.is_file() and p.name not in ("result.json", "evidence.tar.gz")]
sources += [("audit.json", base / "audit.json"), ("commit-map.tsv", base / "commit-map.tsv"),
            ("original-refs.txt", base / "original-refs.txt"), ("remote-refs.txt", base / "remote-refs.txt"),
            ("push-plan-at-filter.json", base / "push-plan.json"), ("publish_history.py", base / "publish_history.py")]
members = []
artifact = run / "evidence.tar.gz"
with artifact.open("xb") as out:
    with gzip.GzipFile(fileobj=out, filename="", mode="wb", mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w|") as tar:
            for name, path in sources:
                data = path.read_bytes()
                info = tarfile.TarInfo("history-rewrite-20261122/" + name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
                members.append({"member": info.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
with tarfile.open(artifact) as tar:
    for member in members:
        assert hashlib.sha256(tar.extractfile(member["member"]).read()).hexdigest() == member["sha256"]
result = {
    "recorded_utc": datetime.now(timezone.utc).isoformat(),
    "status": "local_history_rewrite_verified_remote_publication_pending",
    "user_objective": "Reduce repository and full-clone size, preserving original evidence separately.",
    "history_acceptance": {"passed": True, "rewritten_commits": len(audit["commits"]), "audited_refs": len(audit["refs"]),
                           "all_retained_blobs_and_modes_identical": True,
                           "independent_metadata_audit": load("independent-metadata-audit.json"),
                           "source_fingerprint": load("native-source-fingerprint.json"),
                           "fsck_passed": True, "filtered_mirror_has_no_alternates": True,
                           "kept_run_paths": len(audit["retained_run_paths"]),
                           "map": "parity/history-commit-map.json.gz",
                           "tool_tests": [{"command": "PYTHONDONTWRITEBYTECODE=1 python3 tools/parity_archive_test.py", "passed": 18, "exit_code": 0, "log": "archive-tests-01.log"},
                                          {"command": "PYTHONDONTWRITEBYTECODE=1 python3 tools/rewrite_parity_history_test.py", "passed": 1, "exit_code": 0, "log": "history-tests-02.log"}],
                           "filtered_pack_bytes": sum(p.stat().st_size for p in (root / ".git/objects/pack").glob("*.pack")),
                           "original_pack_mib": 432.58},
    "independent_complete_clone": clone,
    "local_installation": install,
    "backups": {"bundle": load("backup.json"), "original_git_preserved": install["original_git"],
                "first_cleanup_bundle_preserved": ".local/parity-archive/before-cleanup.bundle",
                "original_author_repair_map_retained_unchanged": True,
                "old_refs_preserved_in_original_git_and_bundle": True,
                "backup_delivery": "Standalone files in ignored storage; copy/store separately from the slim repository. They are not included in clones."},
    "full_product_acceptance": False, "product_test_suites": tests,
    "product_environment_blockers": ["Pinned sibling ponder-upstream and Node/PGlite dependencies unavailable", "Anvil unavailable", "No explicit task-only PostgreSQL URL configured"],
    "focused_upstream_oracles": {"status": "not_run", "reason": "Only archival Git storage changed; native source fingerprint is identical and pinned upstream runtime is unavailable."},
    "parity_credit_added": 0,
    "remote_publication": {"performed": False, "remote_visibility_observed": "public", "existing_remote_heads": 10, "tags": 0,
                           "required_update_mode": "atomic push with exact per-ref force-with-lease",
                           "authorization_blocker": "AGENTS.md permits private publication only; explicit approval is required to publish the rewritten history while retaining public visibility.",
                           "credentials": load("credential-status.json"),
                           "push_plan": ".local/history-rewrite-20261122/push-plan.json",
                           "publisher": ".local/history-rewrite-20261122/publish_history.py",
                           "origin_fetch_suspended_until_publication": True},
    "diagnostics": "The first isolated filter candidate refused direct Codex tree refs. The corrected candidate filters and audits them; the original failure log and candidate metadata are retained. No original evidence or test failure was rewritten as success.",
    "evidence": {"file": str(artifact.relative_to(root)), "bytes": artifact.stat().st_size,
                 "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(), "members": members},
}
(run / "result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"status": result["status"], "clone_git_bytes": clone["clone_git_bytes"], "evidence_bytes": artifact.stat().st_size}, indent=2))
