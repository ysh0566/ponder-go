"""Read the user-supplied credential only for this repository's Git transport."""
from pathlib import Path
import sys

if len(sys.argv) > 1 and sys.argv[1] == "get":
    request = dict(line.rstrip("\n").split("=", 1) for line in sys.stdin if "=" in line)
    if request.get("protocol") == "https" and request.get("host") == "github.com":
        if request.get("path", "ysh0566/ponder-go.git") not in ("ysh0566/ponder-go.git", "ysh0566/ponder-go"):
            raise SystemExit(0)
        value = (Path(__file__).resolve().parents[2] / "token").read_text().strip()
        if not value or "\n" in value or "\r" in value:
            raise SystemExit("Expected one existing credential in token file")
        print("username=ysh0566")
        print("password=" + value)
