"""Record archival acceptance separately from the failed product test suites."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
from datetime import datetime, timezone

root = Path.cwd()
run = root / "parity/runs/archive-cleanup-20261122"
load = lambda name: json.loads((run / name).read_text())
manifest = json.loads((root / "parity/archive-manifest.json").read_text())
recovery = load("full-restore.json")
assert recovery["passed"] and recovery["all_original_files_sha256_and_modes_verified"] == manifest["original"]["files"]
assert "Ran 14 tests" in (run / "archive-tests-05.log").read_text()
assert (run / "archive-tests-05.log").read_text().rstrip().endswith("OK")
assert load("source-fingerprint.json")["identical"]
with gzip.open(root / manifest["catalog"]["path"], "rt") as stream:
    catalog = json.load(stream)
deleted = set(subprocess.check_output(["git", "diff", "--cached", "--no-renames", "--name-only", "--diff-filter=D"], text=True).splitlines())
assert deleted == {entry["path"] for entry in catalog["files"]}
original_paths = [name for name in subprocess.check_output(["git", "ls-tree", "-r", "--name-only", manifest["source_commit"], "--", "parity"], text=True).splitlines() if not name.startswith("parity/runs/")]
subprocess.run(["git", "diff", "--quiet", manifest["source_commit"], "--", *original_paths], check=True)

excluded = {"result.json", "evidence.tar.gz"}
inputs = sorted(p for p in run.iterdir() if p.is_file() and p.name not in excluded)
members = []
archive_path = run / "evidence.tar.gz"
with archive_path.open("xb") as output:
    with gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w|") as tar:
            for path in inputs:
                data = path.read_bytes()
                info = tarfile.TarInfo("archive-cleanup-20261122/" + path.name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
                members.append({"member": info.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
with tarfile.open(archive_path) as tar:
    assert len(tar.getmembers()) == len(members)
    for item in members:
        assert hashlib.sha256(tar.extractfile(item["member"]).read()).hexdigest() == item["sha256"]

packages = load("go-package-results.json")
go_prefix = "PATH=/tmp/ponder-go-parity-tools/go/bin:$PATH GOMODCACHE=/root/go/pkg/mod GOCACHE=/tmp/ponder-go-parity-gocache "
tests = [
    {"command": go_prefix + "go test ./...", "log": "before-go-test.log", "exit_code": 1, "sandbox": "restricted", "stage": "before cleanup"},
    {"command": go_prefix + "go test ./...", "log": "after-go-test.log", "exit_code": 1, "sandbox": "local ports enabled", "stage": "after cleanup"},
    {"command": go_prefix + "go test -race ./...", "log": "after-go-race.log", "exit_code": 1, "sandbox": "local ports enabled", "stage": "after cleanup"},
]
for test in tests:
    test["status"] = "failed"
    test["package_results"] = packages[test["log"]]
result = {
    "recorded_utc": datetime.now(timezone.utc).isoformat(),
    "status": "archive_cleanup_verified_product_acceptance_not_claimed",
    "source_commit": manifest["source_commit"],
    "source_tree": manifest["source_tree"],
    "archival_acceptance": {
        "passed": True,
        "unit_command": "PYTHONDONTWRITEBYTECODE=1 python3 tools/parity_archive_test.py",
        "unit_tests": 14, "unit_exit_code": 0, "unit_log": "archive-tests-05.log",
        "object_verification_command": "python3 tools/parity_archive.py verify",
        "object_verification": load("archive-verify.json"),
        "cleanup_command": "python3 tools/parity_archive.py prune",
        "cleanup": load("prune.json"),
        "independent_recovery_command": "PYTHONDONTWRITEBYTECODE=1 python3 parity/runs/archive-cleanup-20261122/full_restore_check.py",
        "independent_recovery": recovery,
    },
    "original": manifest["original"], "retained": manifest["retained"], "archived": manifest["archived"],
    "native_source_fingerprint": load("source-fingerprint.json"),
    "original_source_audit": load("original-source-audit.json"),
    "product_test_suites": tests,
    "full_product_acceptance": False,
    "test_environment_blockers": [
        "No explicit task-only PONDER_TEST_POSTGRES URL was configured; no database connection was supplied.",
        "Pinned sibling ponder-upstream and its Node/PGlite dependencies are absent (MODULE_NOT_FOUND).",
        "Existing Anvil is required by local-chain integration tests but is unavailable.",
        "The initial restricted run also disallowed local test sockets; subsequent normal/race runs enabled local sockets and still failed on missing prerequisites.",
    ],
    "focused_upstream_oracles": {"status": "not_run", "reason": "Storage-only cleanup; all 104 retained original test source hashes were checked, native sources are unchanged, and the pinned upstream runtime is unavailable."},
    "parity_credit_added": 0,
    "history": {"rewritten": False, "refs_deleted": False, "force_push": False,
                "reason": "The existing compressed pack was 432.58 MiB. Keeping unchanged ancestor history makes every indexed evidence blob recoverable offline; rewriting is unnecessary to remove 6.4 GiB from the working tree.",
                "independent_backup": load("backup.json")},
    "publication": {"performed": False, "verified_github_login": "ysh0566", "verified_github_user_id": 19503475,
                    "repository_visibility_observed": "public", "reason": "Existing authorization permits publication only to a private ysh0566 repository. No remote write was made."},
    "diagnostics": "Intermediate tool-test failures are preserved in the evidence archive. Historical discovery-audit support hash mismatches already present in HEAD are recorded separately; their source bytes and the ledger were preserved, not repaired or credited.",
    "evidence": {"file": str(archive_path.relative_to(root)), "bytes": archive_path.stat().st_size,
                 "sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(), "members": members},
    "review": {"native_sources_unchanged": True, "archive_deletions_match_catalog": True,
               "new_runs_ignored_by_default": True, "whitespace_check": "git diff --cached --no-renames --diff-filter=AM --check"},
}
(run / "result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"status": result["status"], "evidence_bytes": archive_path.stat().st_size, "result": str((run / "result.json").relative_to(root))}, indent=2))
