"""Restore all real archived evidence from the independent pre-cleanup bundle."""
import json
from pathlib import Path
import shutil
import sys
import tempfile
import time

root = Path.cwd()
sys.path.insert(0, str(root / "tools"))
import parity_archive as archive

report = root / "parity/runs/archive-cleanup-20261122/full-restore.json"
fresh = Path(tempfile.mkdtemp(prefix="ponder-go-parity-full-restore-"))
started = time.time()
result = {"destination": str(fresh), "passed": False}
try:
    manifest, entries = archive.load_archive(root)
    required = manifest["original"]["bytes"] + 453223734 + 256 * 1024 * 1024
    if shutil.disk_usage(fresh).free < required:
        raise RuntimeError("Insufficient space for complete independent restoration")
    archive.git(fresh, "init", "-b", "main")
    archive.git(fresh, "fetch", "--no-tags", str(root / ".local/parity-archive/before-cleanup.bundle"), "HEAD")
    for name in (archive.MANIFEST, archive.CATALOG):
        target = fresh / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / name, target)
    result["restore"] = archive.restore(fresh)
    # A normal lightweight clone already has these committed summaries. Copy
    # their unchanged bytes to model that checkout and then audit the full tree.
    for entry in manifest["retained_files"]:
        source = archive.safe_path(root, entry["path"])
        archive.unchanged(source, entry)
        target = archive.safe_path(fresh, entry["path"])
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    all_entries = entries + manifest["retained_files"]
    for number, entry in enumerate(all_entries, 1):
        archive.unchanged(archive.safe_path(fresh, entry["path"]), entry)
        archive.progress("audit restored bytes and modes", number, len(all_entries))
    result.update({"passed": True, "archived_files_restored": len(entries),
                   "all_original_files_sha256_and_modes_verified": len(all_entries),
                   "original_bytes_verified": manifest["original"]["bytes"],
                   "independent_git_object_store": True, "network_used": False})
    shutil.rmtree(fresh)
    result["temporary_restore_removed"] = True
except BaseException as error:
    result["error"] = repr(error)
    raise
finally:
    result["elapsed_seconds"] = round(time.time() - started, 3)
    report.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
